import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:html' as html; // Import cho web
import 'dart:io' as io;
import '../models/product.dart';
import '../services/product_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ProductFormScreen extends StatefulWidget {
  final Product? product; // Để chỉnh sửa sản phẩm đã có
  ProductFormScreen({this.product});

  @override
  _ProductFormScreenState createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  html.File? _imageFile; // Sử dụng File từ package html
  String? _imageUrl;
  String? _selectedCategory; // Biến để lưu lựa chọn category

  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final ProductService _productService = ProductService(); // Khởi tạo ProductService

  // Danh sách các category
  final List<String> _categories = [
    'Thực phẩm',
    'Điện tử',
    'Quần áo',
    'Khác',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.product != null) {
      // Nếu đang chỉnh sửa sản phẩm
      _nameController.text = widget.product!.name;
      _selectedCategory = widget.product!.category;
      _priceController.text = widget.product!.price.toString();
      _imageUrl = widget.product!.imageUrl; // Giữ lại URL hình ảnh
    }
  }

  // Hàm chọn ảnh cho web
  Future<void> _pickImage() async {
    final input = html.FileUploadInputElement();
    input.accept = 'image/*'; // Chỉ cho phép chọn ảnh
    input.click(); // Kích hoạt hộp thoại chọn file

    input.onChange.listen((e) async {
      final reader = html.FileReader();
      reader.readAsDataUrl(input.files![0]); // Đọc file
      reader.onLoadEnd.listen((e) async {
        setState(() {
          _imageFile = input.files![0]; // Lưu file đã chọn
          _imageUrl = reader.result as String; // Hiển thị hình ảnh ngay lập tức
        });
      });
    });
  }

  // Hàm upload ảnh và lấy URL
  Future<void> _uploadImage() async {
    if (_imageFile != null) {
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      Reference ref = FirebaseStorage.instance.ref().child('images/$fileName');

      // Upload file
      UploadTask uploadTask = ref.putBlob(_imageFile!); // Sử dụng putBlob cho web
      TaskSnapshot taskSnapshot = await uploadTask;

      // Lấy URL của hình ảnh đã upload
      String downloadUrl = await taskSnapshot.ref.getDownloadURL();
      setState(() {
        _imageUrl = downloadUrl;
      });
    }
  }

  // Hàm lưu sản phẩm
  // Hàm lưu sản phẩm
  void _saveProduct() async {
    if (_nameController.text.isEmpty || _selectedCategory == null || _priceController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please fill in all fields')));
      return;
    }

    // Upload ảnh trước khi lưu sản phẩm
    await _uploadImage();

    // Lưu sản phẩm kèm URL ảnh (_imageUrl)
    final product = Product(
      id: widget.product?.id ?? DateTime.now().millisecondsSinceEpoch.toString(), // Tạo ID tự động nếu không có
      name: _nameController.text,
      category: _selectedCategory.toString(),
      price: double.tryParse(_priceController.text) ?? 0.0,
      imageUrl: _imageUrl ?? '', // Sử dụng giá trị mặc định nếu imageUrl là null
    );

    if (widget.product != null) {
      // Cập nhật sản phẩm nếu đang chỉnh sửa
      await _productService.updateProduct(product);
    } else {
      // Thêm sản phẩm mới
      await _productService.addProduct(product);
    }

    Navigator.pop(context); // Quay lại màn hình danh sách sản phẩm
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Product')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Căn trái
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Product Name'),
            ),
            SizedBox(height: 10),
            // Dropdown cho Category
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              hint: Text('Chọn Category'),
              items: _categories.map((String category) {
                return DropdownMenuItem<String>(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  _selectedCategory = newValue; // Cập nhật lựa chọn category
                });
              },
            ),
            SizedBox(height: 10),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Product Price'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),

            // Vùng chọn ảnh
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                height: 150,
                decoration: BoxDecoration(
                  color: Colors.grey[300], // Màu xám cho vùng chọn ảnh
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: _imageFile != null
                      ? Image.network(
                    _imageUrl!,
                    fit: BoxFit.cover,
                  )
                      : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.camera_alt, size: 40), // Biểu tượng máy ảnh
                      SizedBox(height: 10),
                      Text('Click to select image', style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _saveProduct, child: Text('Save Product')),
          ],
        ),
      ),
    );
  }
}