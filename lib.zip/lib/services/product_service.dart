import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class ProductService {
  final CollectionReference _productsCollection = FirebaseFirestore.instance.collection('products');

  // Lấy danh sách sản phẩm
  Future<List<Product>> getProducts() async {
    final snapshot = await _productsCollection.get();
    return snapshot.docs.map((doc) {
      return Product(
        id: doc.id, // Lấy ID tài liệu
        name: doc['name'],
        category: doc['category'],
        price: doc['price'],
        imageUrl: doc['imageUrl'],
      );
    }).toList();
  }

  // Thêm sản phẩm mới
  Future<void> addProduct(Product product) async {
    await _productsCollection.add({
      'name': product.name,
      'category': product.category,
      'price': product.price,
      'imageUrl': product.imageUrl,
    });
  }

  // Cập nhật sản phẩm
  Future<void> updateProduct(Product product) async {
    await _productsCollection.doc(product.id).update({
      'name': product.name,
      'category': product.category,
      'price': product.price,
      'imageUrl': product.imageUrl,
    });
  }

  // Xóa sản phẩm
  Future<void> deleteProduct(String id) async {
    await _productsCollection.doc(id).delete();
  }
}
